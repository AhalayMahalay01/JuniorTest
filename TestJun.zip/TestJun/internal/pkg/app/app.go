package app

import (
	"TestJun/internal/app/MV"
	"TestJun/internal/app/endpoint"
	"TestJun/internal/app/service"
	"fmt"
	"github.com/labstack/echo/v4"
	"log"
)

type App struct {
	e    *endpoint.Endpoint
	s    *service.Service
	echo *echo.Echo
}

func New() (*App, error) {
	a := &App{}

	a.s = service.New()

	a.e = endpoint.New(a.s)

	a.echo = echo.New()

	a.echo.Use(MV.RoleCheck)

	//Якщо по завданню, потрібно два обробника, то було б краще "MV" передати через s.GET("/status", Handler, MV)

	a.echo.GET("/status", a.e.Status)
	return a, nil
}

func (a *App) Run() error {
	fmt.Println("Server running")

	err := a.echo.Start(":8088")
	if err != nil {
		log.Fatal(err)
	}
	return nil
}
